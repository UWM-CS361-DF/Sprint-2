public class Sensor {
	
	private enum SensorType {GATE, EYE, PAD, MANUAL;}
	private SensorType sensorType;
	

	public Sensor(SensorType sensorType) {
		switch (this.sensorType) {
		case GATE:
			break;
		case EYE:
			break;
		case PAD:
			break;
		case MANUAL:
			break;
		}
	}
	
}