
public interface Event{

	public void start();
	public void finish();
}
